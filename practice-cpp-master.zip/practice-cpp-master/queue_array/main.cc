#include <cstdlib>
#include <iostream>

#include "src/queue_array.h"
#include "src/queue_array.cc"

int main(int argc, char *argv[]) {

  std::cout << "Nothing to see here. Look in tests directory." << std::endl;

  return EXIT_SUCCESS;
}
