#include <iostream>
#include "hash_table.h"

#ifndef PROJECT_HASH_TABLES_TESTS_H
#define PROJECT_HASH_TABLES_TESTS_H

void run_all_tests();

void test_add_exists();
void test_probing();
void test_get();
void test_remove();

#endif  // PROJECT_HASH_TABLES_TESTS_H
