# Practice C++

Part of my daily plan for studying C++.

**Important**

This code may be terrible and buggy. It's been a few months since I've looked at it.