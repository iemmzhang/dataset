#include <stdlib.h>
#include <time.h>

#ifndef PROJECT_QUICK_SORT_H
#define PROJECT_QUICK_SORT_H

namespace jw {

void quick_sort(int numbers[], int left, int right);

} // namespace jw

#endif //PROJECT_QUICK_SORT_H
